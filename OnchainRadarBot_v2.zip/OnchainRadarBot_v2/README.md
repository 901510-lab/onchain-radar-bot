# OnchainRadarBot v2 — Solana + BSC

Смотри инструкции в чате. Быстрый старт: venv → `pip install -r requirements.txt` → `.env` → `python main.py`.
Render: Build `pip install -r requirements.txt`, Start `python main.py`.
